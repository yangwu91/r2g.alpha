#!/bin/bash

#
# IMPORTANT: Change this file only in directory Standalone!

java -jar /opt/selenium/selenium-server.jar standalone